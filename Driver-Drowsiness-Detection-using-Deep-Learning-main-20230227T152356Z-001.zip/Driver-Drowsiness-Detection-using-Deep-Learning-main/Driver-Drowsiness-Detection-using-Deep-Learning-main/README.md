Tutorial Link:- https://www.youtube.com/watch?v=O5_--oZPbgQ&t=2s

Data Preparation has been updated with train and test folder split automation.
